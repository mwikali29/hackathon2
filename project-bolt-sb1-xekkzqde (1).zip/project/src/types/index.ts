export interface Customer {
  id: string;
  business_id: string | null;
  phone_number: string;
  first_name: string | null;
  last_name: string | null;
  visit_count: number;
  last_visit_at: string | null;
  created_at: string;
  visits: Visit[];
  redeemed_rewards: RedeemedReward[];
}

export interface Visit {
  id: string;
  customer_id: string;
  business_id: string | null;
  visit_at: string;
}

export interface RedeemedReward {
  id: string;
  customer_id: string;
  reward_tier_id: string | null;
  redeemed_at: string;
}

export interface Database {
  public: {
    Tables: {
      customers: {
        Row: {
          id: string;
          business_id: string | null;
          phone_number: string;
          first_name: string | null;
          last_name: string | null;
          visit_count: number;
          last_visit_at: string | null;
          created_at: string;
        };
      };
      visits: {
        Row: {
          id: string;
          customer_id: string;
          business_id: string | null;
          visit_at: string;
        };
      };
      redeemed_rewards: {
        Row: {
          id: string;
          customer_id: string;
          reward_tier_id: string | null;
          redeemed_at: string;
        };
      };
    };
  };
}