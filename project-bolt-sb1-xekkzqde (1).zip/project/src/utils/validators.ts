/**
 * Validates and formats a phone number
 * @param phoneNumber The phone number to validate
 * @returns The formatted phone number or null if invalid
 */
export const validatePhoneNumber = (phoneNumber: string): string | null => {
  // Remove all non-digit characters
  const digitsOnly = phoneNumber.replace(/\D/g, '');
  
  // Check if we have a valid number of digits (10 for US)
  if (digitsOnly.length !== 10) {
    return null;
  }
  
  // Format as (XXX) XXX-XXXX
  return `(${digitsOnly.slice(0, 3)}) ${digitsOnly.slice(3, 6)}-${digitsOnly.slice(6)}`;
};

/**
 * Formats a date as a readable string
 * @param date The date to format
 * @returns Formatted date string
 */
export const formatDate = (date: string): string => {
  return new Date(date).toLocaleString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
    hour12: true
  });
};