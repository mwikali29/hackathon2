import React, { useState, useEffect } from 'react';
import { Phone } from 'lucide-react';
import CustomerForm from './components/CustomerForm';
import CustomerList from './components/CustomerList';
import { getAllCustomers } from './services/customerService';
import type { Customer } from './types';

function App() {
  const [customers, setCustomers] = useState<Customer[]>([]);
  
  const loadCustomers = async () => {
    const data = await getAllCustomers();
    setCustomers(data);
  };

  useEffect(() => {
    loadCustomers();
  }, []);

  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-white shadow-sm">
        <div className="max-w-5xl mx-auto px-4 py-5 sm:px-6">
          <div className="flex items-center">
            <div className="bg-blue-600 p-2 rounded-md">
              <Phone className="h-6 w-6 text-white" />
            </div>
            <h1 className="ml-3 text-2xl font-bold text-gray-900">Customer Tracker</h1>
          </div>
        </div>
      </header>
      
      <main className="max-w-5xl mx-auto px-4 py-8 sm:px-6">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
          <div className="md:col-span-1">
            <CustomerForm onCustomerAdded={loadCustomers} />
            
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-medium text-gray-800 mb-4">Quick Stats</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-blue-50 p-4 rounded-md">
                  <p className="text-sm text-blue-700 font-medium">Total Customers</p>
                  <p className="text-2xl font-bold text-blue-800">{customers.length}</p>
                </div>
                <div className="bg-indigo-50 p-4 rounded-md">
                  <p className="text-sm text-indigo-700 font-medium">Total Visits</p>
                  <p className="text-2xl font-bold text-indigo-800">
                    {customers.reduce((sum, customer) => sum + (customer.visits?.length || 0), 0)}
                  </p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="md:col-span-2">
            <CustomerList 
              customers={customers} 
              onCustomerDeleted={loadCustomers}
              onRewardRedeemed={loadCustomers}
            />
          </div>
        </div>
      </main>
      
      <footer className="bg-white border-t border-gray-200 mt-12">
        <div className="max-w-5xl mx-auto px-4 py-6 sm:px-6">
          <p className="text-center text-gray-500 text-sm">
            &copy; {new Date().getFullYear()} Customer Tracker. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;