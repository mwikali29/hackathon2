import { supabase } from '../lib/supabase';
import type { Customer, Visit, RedeemedReward } from '../types';

export const getCustomerByPhone = async (phoneNumber: string): Promise<Customer | null> => {
  const { data: customer, error } = await supabase
    .from('customers')
    .select('*, visits(*), redeemed_rewards(*)')
    .eq('phone_number', phoneNumber)
    .maybeSingle();

  if (error || !customer) {
    return null;
  }

  return customer;
};

export const getAllCustomers = async (): Promise<Customer[]> => {
  const { data } = await supabase
    .from('customers')
    .select('*, visits(*), redeemed_rewards(*)')
    .order('created_at', { ascending: false });

  return data || [];
};

export const logVisit = async (phoneNumber: string, notes?: string): Promise<Customer | null> => {
  // First, get or create customer
  let { data: existingCustomer } = await supabase
    .from('customers')
    .select('*')
    .eq('phone_number', phoneNumber)
    .maybeSingle();

  let customer;
  if (!existingCustomer) {
    // Only create a new customer if one doesn't exist
    const { data: newCustomer, error: createError } = await supabase
      .from('customers')
      .insert({ phone_number: phoneNumber, visit_count: 1 })
      .select()
      .single();

    if (createError || !newCustomer) {
      console.error('Error creating customer:', createError);
      return null;
    }
    customer = newCustomer;
  } else {
    // Update existing customer's visit count
    const { data: updatedCustomer, error: updateError } = await supabase
      .from('customers')
      .update({ visit_count: existingCustomer.visit_count + 1 })
      .eq('id', existingCustomer.id)
      .select()
      .single();

    if (updateError || !updatedCustomer) {
      console.error('Error updating customer:', updateError);
      return null;
    }
    customer = updatedCustomer;
  }

  // Log the visit
  const { error: visitError } = await supabase
    .from('visits')
    .insert({
      customer_id: customer.id,
      notes: notes || null
    });

  if (visitError) {
    console.error('Error logging visit:', visitError);
    return null;
  }

  // Return updated customer with all related data
  const { data: fullCustomer } = await supabase
    .from('customers')
    .select('*, visits(*), redeemed_rewards(*)')
    .eq('id', customer.id)
    .single();

  return fullCustomer || null;
};

export const redeemReward = async (customerId: string): Promise<Customer | null> => {
  // Reset visit count and create redemption record
  const { data: customer, error: updateError } = await supabase
    .from('customers')
    .update({ visit_count: 0 })
    .eq('id', customerId)
    .select()
    .single();

  if (updateError || !customer) {
    return null;
  }

  const { error: rewardError } = await supabase
    .from('redeemed_rewards')
    .insert({
      customer_id: customerId,
      reward_tier_id: null // This should be set to an actual reward tier ID
    });

  if (rewardError) {
    return null;
  }

  // Return updated customer with all related data
  const { data: fullCustomer } = await supabase
    .from('customers')
    .select('*, visits(*), redeemed_rewards(*)')
    .eq('id', customerId)
    .single();

  return fullCustomer || null;
};

export const deleteCustomer = async (id: string): Promise<void> => {
  await supabase
    .from('customers')
    .delete()
    .eq('id', id);
};