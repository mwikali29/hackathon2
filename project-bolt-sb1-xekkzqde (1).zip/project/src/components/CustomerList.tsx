import React, { useState } from 'react';
import { Search, User, Calendar, ChevronDown, ChevronUp, Trash2, Gift } from 'lucide-react';
import { Customer } from '../types';
import { formatDate } from '../utils/validators';
import { deleteCustomer, redeemReward } from '../services/customerService';

interface CustomerListProps {
  customers: Customer[];
  onCustomerDeleted: () => void;
  onRewardRedeemed: () => void;
}

const VISITS_FOR_REWARD = 10;

const CustomerList: React.FC<CustomerListProps> = ({ 
  customers, 
  onCustomerDeleted,
  onRewardRedeemed 
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [expandedCustomerId, setExpandedCustomerId] = useState<string | null>(null);
  
  const filteredCustomers = customers.filter(customer => 
    customer.phone_number.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  const sortedCustomers = [...filteredCustomers].sort((a, b) => {
    return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
  });
  
  const toggleExpand = (id: string) => {
    setExpandedCustomerId(expandedCustomerId === id ? null : id);
  };
  
  const handleDelete = async (id: string, event: React.MouseEvent) => {
    event.stopPropagation();
    if (window.confirm('Are you sure you want to delete this customer?')) {
      await deleteCustomer(id);
      onCustomerDeleted();
    }
  };

  const handleRedeemReward = async (customerId: string, event: React.MouseEvent) => {
    event.stopPropagation();
    await redeemReward(customerId);
    onRewardRedeemed();
  };

  const getRemainingVisits = (visitCount: number) => {
    return VISITS_FOR_REWARD - visitCount;
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-semibold text-gray-800 mb-4">Customer History</h2>
      
      <div className="relative mb-4">
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          <Search className="h-5 w-5 text-gray-400" />
        </div>
        <input
          type="text"
          placeholder="Search by phone number..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-10 block w-full rounded-md border border-gray-300 shadow-sm py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
        />
      </div>
      
      {sortedCustomers.length === 0 ? (
        <div className="text-center py-6 text-gray-500">
          {searchTerm ? 'No customers found matching your search.' : 'No customers yet. Add one to get started!'}
        </div>
      ) : (
        <ul className="space-y-3">
          {sortedCustomers.map(customer => (
            <li 
              key={customer.id} 
              className="border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors duration-200"
            >
              <div 
                className="p-4 flex justify-between items-center cursor-pointer"
                onClick={() => toggleExpand(customer.id)}
              >
                <div className="flex items-center">
                  <User className="h-5 w-5 text-gray-500 mr-3" />
                  <div>
                    <div className="font-medium text-gray-800">{customer.phone_number}</div>
                    <div className="text-sm text-gray-500 flex items-center">
                      <Calendar className="h-4 w-4 mr-1" />
                      <span>{customer.visits?.length || 0} visits</span>
                      <span className="mx-1">•</span>
                      <span>{getRemainingVisits(customer.visit_count)} visits until next reward</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  {customer.visit_count >= VISITS_FOR_REWARD && (
                    <button
                      onClick={(e) => handleRedeemReward(customer.id, e)}
                      className="flex items-center px-3 py-1 bg-green-100 text-green-700 rounded-md hover:bg-green-200 transition-colors"
                    >
                      <Gift className="h-4 w-4 mr-1" />
                      Redeem Reward
                    </button>
                  )}
                  <button
                    onClick={(e) => handleDelete(customer.id, e)}
                    className="text-gray-400 hover:text-red-500 focus:outline-none"
                    aria-label="Delete customer"
                  >
                    <Trash2 className="h-5 w-5" />
                  </button>
                  {expandedCustomerId === customer.id ? (
                    <ChevronUp className="h-5 w-5 text-gray-500" />
                  ) : (
                    <ChevronDown className="h-5 w-5 text-gray-500" />
                  )}
                </div>
              </div>
              
              {expandedCustomerId === customer.id && (
                <div className="px-4 pb-4 pt-0 border-t border-gray-200 mt-1">
                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div className="bg-blue-50 p-3 rounded-md">
                      <h4 className="text-sm font-medium text-blue-700">Visit Progress</h4>
                      <p className="text-2xl font-bold text-blue-800">
                        {customer.visit_count} / {VISITS_FOR_REWARD}
                      </p>
                      <p className="text-sm text-blue-600 mt-1">
                        {getRemainingVisits(customer.visit_count)} visits until next reward
                      </p>
                    </div>
                    <div className="bg-green-50 p-3 rounded-md">
                      <h4 className="text-sm font-medium text-green-700">Rewards Redeemed</h4>
                      <p className="text-2xl font-bold text-green-800">
                        {customer.redeemed_rewards?.length || 0}
                      </p>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <h4 className="font-medium text-sm text-gray-700 mb-2">Visit History</h4>
                      <ul className="space-y-2">
                        {customer.visits?.map(visit => (
                          <li key={visit.id} className="text-sm pl-3 border-l-2 border-blue-200">
                            <div className="font-medium text-gray-800">{formatDate(visit.created_at)}</div>
                            {visit.notes && <p className="text-gray-600 mt-1">{visit.notes}</p>}
                          </li>
                        ))}
                      </ul>
                    </div>

                    {customer.redeemed_rewards?.length > 0 && (
                      <div>
                        <h4 className="font-medium text-sm text-gray-700 mb-2">Redeemed Rewards</h4>
                        <ul className="space-y-2">
                          {customer.redeemed_rewards.map(reward => (
                            <li key={reward.id} className="text-sm pl-3 border-l-2 border-green-200">
                              <div className="font-medium text-gray-800">{formatDate(reward.created_at)}</div>
                              <p className="text-gray-600">{reward.notes}</p>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default CustomerList;