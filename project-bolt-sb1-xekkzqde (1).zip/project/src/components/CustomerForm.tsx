import React, { useState } from 'react';
import { Phone } from 'lucide-react';
import { validatePhoneNumber } from '../utils/validators';
import { logVisit } from '../services/customerService';

interface CustomerFormProps {
  onCustomerAdded: () => void;
}

const CustomerForm: React.FC<CustomerFormProps> = ({ onCustomerAdded }) => {
  const [phoneNumber, setPhoneNumber] = useState('');
  const [notes, setNotes] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    
    const formattedNumber = validatePhoneNumber(phoneNumber);
    
    if (!formattedNumber) {
      setError('Please enter a valid 10-digit phone number');
      return;
    }
    
    try {
      logVisit(formattedNumber, notes);
      setSuccess(true);
      setPhoneNumber('');
      setNotes('');
      onCustomerAdded();
      
      // Reset success message after 3 seconds
      setTimeout(() => {
        setSuccess(false);
      }, 3000);
    } catch (err) {
      setError('Failed to log visit. Please try again.');
    }
  };

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    // Allow only digits, spaces, parentheses, and hyphens
    const filtered = e.target.value.replace(/[^\d\s\(\)\-]/g, '');
    setPhoneNumber(filtered);
    setError(null);
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6 mb-6 transition-all duration-300 hover:shadow-lg">
      <h2 className="text-2xl font-semibold text-gray-800 mb-4">Log Customer Visit</h2>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="phoneNumber" className="block text-sm font-medium text-gray-700 mb-1">
            Phone Number
          </label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Phone className="h-5 w-5 text-gray-400" />
            </div>
            <input
              id="phoneNumber"
              type="tel"
              placeholder="(555) 123-4567"
              value={phoneNumber}
              onChange={handlePhoneChange}
              className={`pl-10 block w-full rounded-md border ${
                error ? 'border-red-500' : 'border-gray-300'
              } shadow-sm py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500`}
              required
            />
          </div>
          {error && <p className="mt-1 text-sm text-red-600">{error}</p>}
        </div>
        
        <div>
          <label htmlFor="notes" className="block text-sm font-medium text-gray-700 mb-1">
            Notes (Optional)
          </label>
          <textarea
            id="notes"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            rows={3}
            className="block w-full rounded-md border border-gray-300 shadow-sm py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            placeholder="Add any notes about this visit..."
          />
        </div>
        
        <div className="pt-2">
          <button
            type="submit"
            className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors duration-300"
          >
            Log Visit
          </button>
        </div>
      </form>
      
      {success && (
        <div className="mt-4 p-3 bg-green-100 border border-green-200 text-green-800 rounded-md animate-fade-in">
          Visit logged successfully!
        </div>
      )}
    </div>
  );
};

export default CustomerForm;