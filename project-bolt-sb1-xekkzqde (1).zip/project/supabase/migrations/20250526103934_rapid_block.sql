/*
  # Fix visits table RLS policy

  1. Changes
    - Update the INSERT policy to be less restrictive
    - Allow inserts with just a valid customer_id
    - Make business_id optional in the policy check
  
  2. Security
    - Maintains basic security while allowing necessary operations
    - Ensures visits can only be associated with existing customers
*/

-- Drop existing insert policy
DROP POLICY IF EXISTS "Allow insert for authenticated users" ON visits;

-- Create new, more permissive insert policy
CREATE POLICY "Allow insert for authenticated users"
ON visits FOR INSERT
TO authenticated
WITH CHECK (
  -- Only check that the customer exists
  EXISTS (
    SELECT 1 FROM customers c
    WHERE c.id = customer_id
  )
  -- No check for business_id since it's optional
);