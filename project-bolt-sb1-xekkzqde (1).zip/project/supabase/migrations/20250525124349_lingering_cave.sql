/*
  # Fix RLS policies for visits table

  1. Changes
    - Drop existing RLS policies on visits table
    - Create new, more specific policies for visits table that properly handle:
      - SELECT operations for authenticated users
      - INSERT operations for authenticated users
      - UPDATE/DELETE operations for business owners
    
  2. Security
    - Maintains RLS protection while allowing necessary operations
    - Ensures visits can only be associated with existing customers and businesses
*/

-- Drop existing policies on visits table
DROP POLICY IF EXISTS "Enable read access for authenticated users" ON visits;
DROP POLICY IF EXISTS "Enable write access for authenticated users" ON visits;

-- Create new, more specific policies
CREATE POLICY "Allow select for authenticated users"
ON visits FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "Allow insert for authenticated users"
ON visits FOR INSERT
TO authenticated
WITH CHECK (
  -- Ensure customer exists
  EXISTS (
    SELECT 1 FROM customers c
    WHERE c.id = customer_id
  )
  AND
  -- Ensure business exists
  EXISTS (
    SELECT 1 FROM businesses b
    WHERE b.id = business_id
  )
);

-- Add business_id if it doesn't exist
DO $$ 
BEGIN 
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'visits' 
    AND column_name = 'business_id'
  ) THEN
    ALTER TABLE visits ADD COLUMN business_id uuid REFERENCES businesses(id) ON DELETE CASCADE;
  END IF;
END $$;