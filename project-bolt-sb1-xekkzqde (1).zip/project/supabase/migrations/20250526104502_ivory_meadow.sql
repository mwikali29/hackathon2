/*
  # Fix visits table schema and RLS policies

  1. Changes
    - Recreates visits table with proper schema
    - Preserves existing data during migration
    - Updates RLS policies for better security
  
  2. Security
    - Enables RLS on visits table
    - Adds policies for authenticated users
    - Simplifies policy checks
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Allow select for authenticated users" ON visits;
DROP POLICY IF EXISTS "Allow insert for authenticated users" ON visits;

-- Recreate visits table with correct schema
CREATE TABLE IF NOT EXISTS visits_new (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid REFERENCES customers(id) ON DELETE CASCADE,
  business_id uuid REFERENCES businesses(id) ON DELETE CASCADE,
  notes text,
  visit_at timestamptz DEFAULT now()
);

-- Copy data if old table exists
DO $$
BEGIN
  IF EXISTS (SELECT FROM pg_tables WHERE tablename = 'visits') THEN
    INSERT INTO visits_new (id, customer_id, business_id, visit_at)
    SELECT id, customer_id, business_id, visit_at
    FROM visits;
  END IF;
END $$;

-- Drop old table and rename new one
DROP TABLE IF EXISTS visits;
ALTER TABLE visits_new RENAME TO visits;

-- Enable RLS
ALTER TABLE visits ENABLE ROW LEVEL SECURITY;

-- Create new policies
CREATE POLICY "Allow select for authenticated users"
ON visits FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "Allow insert for authenticated users"
ON visits FOR INSERT
TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1
    FROM customers c
    WHERE c.id = customer_id
  )
);