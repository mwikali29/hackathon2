/*
  # Add reward tracking tables and policies

  1. Tables
    - Ensures visits table exists with customer_id foreign key
    - Ensures redeemed_rewards table exists for tracking reward redemptions
  
  2. Security
    - Enables RLS on all tables
    - Adds policies for authenticated users
*/

-- Create visits table if it doesn't exist
CREATE TABLE IF NOT EXISTS visits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid REFERENCES customers(id) ON DELETE CASCADE,
  notes text,
  created_at timestamptz DEFAULT now()
);

-- Create redeemed_rewards table if it doesn't exist
CREATE TABLE IF NOT EXISTS redeemed_rewards (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid REFERENCES customers(id) ON DELETE CASCADE,
  notes text DEFAULT 'Free Coffee Reward',
  created_at timestamptz DEFAULT now()
);

-- Add visit_count to customers if it doesn't exist
DO $$ 
BEGIN 
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'customers' 
    AND column_name = 'visit_count'
  ) THEN
    ALTER TABLE customers ADD COLUMN visit_count integer DEFAULT 0;
  END IF;
END $$;

-- Enable RLS
ALTER TABLE visits ENABLE ROW LEVEL SECURITY;
ALTER TABLE redeemed_rewards ENABLE ROW LEVEL SECURITY;

-- Create policies for visits
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'visits' 
    AND policyname = 'Enable read access for authenticated users'
  ) THEN
    CREATE POLICY "Enable read access for authenticated users" ON visits
      FOR SELECT TO authenticated USING (true);
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'visits' 
    AND policyname = 'Enable write access for authenticated users'
  ) THEN
    CREATE POLICY "Enable write access for authenticated users" ON visits
      FOR ALL TO authenticated USING (true);
  END IF;
END $$;

-- Create policies for redeemed_rewards
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'redeemed_rewards' 
    AND policyname = 'Enable read access for authenticated users'
  ) THEN
    CREATE POLICY "Enable read access for authenticated users" ON redeemed_rewards
      FOR SELECT TO authenticated USING (true);
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'redeemed_rewards' 
    AND policyname = 'Enable write access for authenticated users'
  ) THEN
    CREATE POLICY "Enable write access for authenticated users" ON redeemed_rewards
      FOR ALL TO authenticated USING (true);
  END IF;
END $$;